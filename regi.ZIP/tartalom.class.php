<?php
class Tartalom
{
    private $id;
    private $sutiid;
    private $mentes;
}







?>