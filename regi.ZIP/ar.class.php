<?php
class Ar
{
    private $id;
    private $sutiid;
    private $ertek;
    private $egyseg;
}


?>