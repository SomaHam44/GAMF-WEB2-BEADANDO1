GAMF WEB2 BEADANDÓ1
<br>
Téma: Cukrászda
<br>
Projekt neve: Édes Élmény
<br>
Készítette: Solti Soma és Adameczné Fekete Andrea
