<section>
	<div class="content">
		<h1>Hírek</h1>
        <p>Vélemények</p>	        
	</div>
    <label>Vélemény: </label>
    <textarea></textarea>
</section>