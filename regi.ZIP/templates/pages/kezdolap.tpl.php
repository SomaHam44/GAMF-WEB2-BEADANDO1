<section>
	<div class="content">
		<h1>Édes Élmény Cukrászda</h1>
		<p>Üdvözöljük az Édes Élmény Cukrászdában</p>		        
	</div>
</section>
