<h2>Regisztráció</h2>
<form action = "<?= SITE_ROOT ?>regisztral" method="post">
    <fieldset>              
        <label for="csaladi_nev">Vezetéknév:</label><input type="text" name="csaladi_nev" required><br><br>
        <label for="utonev">Utónév:</label><input type="text" name="utonev" required><br><br>
        <label for="login">Felhasználó:</label><input type="text" name="login" required><br><br>
        <label for="password">Jelszó:</label><input type="password" name="password"  required><br><br>
        <input type="submit" name="regisztracio" value="Regisztráció">                
    </fieldset>
</form>
<h2><br><?= (isset($viewData['uzenet']) ? $viewData['uzenet'] : "") ?><br></h2>
