<h2>
    <br>Alapinfók:<br>
    <br>Alapinfó 1<br>
    <br>Alapinfó 2<br>
</h2>
